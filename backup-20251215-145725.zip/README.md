
  # Insert Page Functionality

  This is a code bundle for Insert Page Functionality. The original project is available at https://www.figma.com/design/FRjYsBr2bTsvQn1cUqqJuz/Insert-Page-Functionality.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  